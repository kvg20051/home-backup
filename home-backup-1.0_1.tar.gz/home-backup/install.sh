#!/bin/sh
# Установка home-backup. Запуск: sudo ./install.sh
set -e
[ "$(id -u)" -eq 0 ] || { echo "Запустите через sudo"; exit 1; }
cd "$(dirname "$0")"

command -v rsync >/dev/null || apt-get install -y rsync

install -m 0755 home-backup         /usr/local/sbin/home-backup
install -d -m 0755                  /etc/home-backup
[ -e /etc/home-backup/home-backup.conf ] || install -m 0644 home-backup.conf /etc/home-backup/home-backup.conf
[ -e /etc/home-backup/exclude.list ]     || install -m 0644 exclude.list     /etc/home-backup/exclude.list
install -m 0644 home-backup.service /etc/systemd/system/home-backup.service
install -m 0644 home-backup.timer   /etc/systemd/system/home-backup.timer
install -d -m 0755                  /usr/local/share/doc/home-backup
install -m 0644 README.md           /usr/local/share/doc/home-backup/README.md

systemctl daemon-reload

cat <<MSG

Установлено. Дальше:
  1. sudo nano /etc/home-backup/home-backup.conf     # DEST, удалённая копия, почта
  2. sudo home-backup run                            # первый запуск вручную
  3. sudo systemctl enable --now home-backup.timer   # включить расписание
  4. systemctl list-timers home-backup.timer         # проверить

Существующие конфиги в /etc/home-backup не перезаписываются.
MSG
